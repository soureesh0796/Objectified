package com.cognizant.academy.Model;

public class Stack {

}
