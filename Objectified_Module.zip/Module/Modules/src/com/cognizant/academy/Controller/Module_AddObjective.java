package com.cognizant.academy.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.academy.Model.Module_Bo;

public class Module_AddObjective extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Module_AddObjective() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		String Mod_name=(String) session.getAttribute("Mod");
		System.out.println(Mod_name);
		String Objective=request.getParameter("objective");
		Module_Bo bo=new Module_Bo(); 
		boolean result=bo.addObjective(Mod_name,Objective);
		 RequestDispatcher dispatcher=null;
	        
	        if (result)
	        {
	        dispatcher = request.getRequestDispatcher("Module_modlist");
	        dispatcher.forward(request, response);
	        }
	        else
	        {
	        dispatcher = request.getRequestDispatcher("Module_modlist");
	        dispatcher.forward(request, response);
	        }
		
	}

}
