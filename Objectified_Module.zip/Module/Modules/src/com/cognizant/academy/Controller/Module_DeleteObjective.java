package com.cognizant.academy.Controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.academy.Model.Module_Bo;

public class Module_DeleteObjective extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Module_DeleteObjective() {
        super();
        // TODO Auto-generated constructor stub
    }

	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String[] names = request.getParameterValues("chk1");
		 Module_Bo bo=new Module_Bo(); 
		  for(String s:names)
		  {
			 boolean b=bo.removeObjective(s);
		  }
		  RequestDispatcher dis=request.getRequestDispatcher("Module_modlist");
		  dis.forward(request, response);

	}

}
