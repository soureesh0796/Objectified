package com.cognizant.academy.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Module_Bo;

public class AddModuleServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
   
    public AddModuleServlet() 
    {
        super();
       
    }

	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		Module module=new Module();
        String name=request.getParameter("name");        
        module.setMod_name(name);
        Module_Bo modulebo=new Module_Bo();
        boolean result=modulebo.addModule(module);
        RequestDispatcher dispatcher=null;
        
        if (result)
        {
        dispatcher = request.getRequestDispatcher("Module_modlist");
        dispatcher.forward(request, response);
        }
        else
        {
        dispatcher = request.getRequestDispatcher("Module_modlist");
        dispatcher.forward(request, response);
        }

  }

}


