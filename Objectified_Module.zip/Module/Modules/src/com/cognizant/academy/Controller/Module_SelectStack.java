package com.cognizant.academy.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.academy.Model.Module_Bo;
import com.cognizant.academy.Model.Objective;

public class Module_SelectStack extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
   
    public Module_SelectStack() 
    {
        super();
        // TODO Auto-generated constructor stub
    }

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String stack=request.getParameter("stack_name");
		request.setAttribute("Stack_name",stack);
		Module_Bo modulebo=new Module_Bo();
	    List<String> olist=modulebo.fetchObjective_names(stack);
		request.setAttribute("ObjNames",olist);
		RequestDispatcher dis=request.getRequestDispatcher("Module_modlist");
		dis.forward(request, response);
	}

}
