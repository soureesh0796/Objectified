package com.cognizant.academy.Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.academy.Model.Module_Bo;
import com.cognizant.academy.Model.Objective;

public class Module_modlist extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Module_modlist() {
        super();
        // TODO Auto-generated constructor stub
    }
    @Override
    public void destroy() {
    	   			
    	super.destroy();
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//HttpSession session=request.getSession();  
        //String course_id=(String)session.getAttribute("course_id");
		HttpSession session=request.getSession();
		String course_id="101";
		if(course_id.equalsIgnoreCase((String)session.getAttribute("Mod_course")))
		{
		}
		else
		{
			session.removeAttribute("Mod");
		}
		session.setAttribute("Mod_course",course_id);
        Module_Bo bo=new Module_Bo();        
        List<String> mlist=bo.getModule_list(course_id);
        List<String> slist=bo.getStack_list();
        List<String> oNames_list=(List<String>) request.getAttribute("ObjNames");
        String stack_name=(String) request.getAttribute("Stack_name");
        
        request.setAttribute("ModList",mlist);
        request.setAttribute("StaList",slist);
        request.setAttribute("ObjNames",oNames_list);
        
        
        //Getting Module from user and displaying the table
        
        String Mod_name=request.getParameter("module");
        if(Mod_name!=null)
        {
        session.setAttribute("Mod", Mod_name);
        }
        
        if((String)session.getAttribute("Mod")==null)
        {
        request.setAttribute("Mod","Select Module");
        }
        else
        {
        	Mod_name=(String)session.getAttribute("Mod");
        	request.setAttribute("Mod",Mod_name);
        }
        List<Objective> olist=bo.fetchobj(Mod_name);
        request.setAttribute("Olist",olist);
       
        
        if(stack_name==null)
        {
        	request.setAttribute("stack_name","Select Stack");
        }
        else
        {
        	request.setAttribute("stack_name",stack_name);
        }
        
        RequestDispatcher dis=request.getRequestDispatcher("Modules.jsp");
        dis.forward(request, response);
	}

	

}
