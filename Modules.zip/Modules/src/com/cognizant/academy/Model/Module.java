package com.cognizant.academy.Model;

public class Module {
	private
	int mod_id;
	String stack_id;
	String Mod_name;
	
	public Module(int mod_id, String stack_id, String mod_name) {
		super();
		this.mod_id = mod_id;
		this.stack_id = stack_id;
		Mod_name = mod_name;
	}
	
	public Module() {
		super();
	}
	
	public int getMod_id() {
		return mod_id;
	}
	
	public void setMod_id(int mod_id) {
		this.mod_id = mod_id;
	}
	
	public String getStack_id() {
		return stack_id;
	}
	
	public void setStack_id(String stack_id) {
		this.stack_id = stack_id;
	}
	
	public String getMod_name() {
		return Mod_name;
	}
	
	public void setMod_name(String mod_name) {
		Mod_name = mod_name;
	}
	

}
