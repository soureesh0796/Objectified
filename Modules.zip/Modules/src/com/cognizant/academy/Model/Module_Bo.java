package com.cognizant.academy.Model;
import java.util.List;

import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.Dao.Module_Dao;


public class Module_Bo {

	public List<String> getModule_list(String course_id) {
		List<String> modlist=Module_Dao.getmodlist(course_id);
		return modlist;
	}
	
	
	public boolean addModule(Module module) 
	{
		  boolean result=Module_Dao.add(module);
          return result;
	}
	
	
	public List<String> getStack_list() 
	{
		List<String> stackList=Module_Dao.getStacklist();
		return stackList;
	}
	
	
	public List<Objective> fetchobj(String name) 
	{
		List<Objective> objList=Module_Dao.getObjectivelist(name);
		return objList;
	}
	
	
	public List<String> fetchObjective_names(String stack) 
	{
		List<String> objList=Module_Dao.getObjectiveNames(stack);
		return objList;	
	}


	public boolean addObjective(String module,String objective) 
	{
		 boolean result=Module_Dao.addObjective(module,objective);
         return result;
	}


	public boolean removeObjective(String s) 
	{
		 boolean result=Module_Dao.removeObjective(s);
         return result;
	}


}
