package com.cognizant.academy.Model;

public class Objective {
 private
 String stack_name,objective_name;
 int duration;
public String getStack_name() {
	return stack_name;
}
public void setStack_name(String stack_name) {
	this.stack_name = stack_name;
}
public String getObjective_name() {
	return objective_name;
}
public void setObjective_name(String objective_name) {
	this.objective_name = objective_name;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
public Objective(String stack_name, String objective_name, int duration) {
	super();
	this.stack_name = stack_name;
	this.objective_name = objective_name;
	this.duration = duration;
}
public Objective() {
	super();
}
 
 
}
