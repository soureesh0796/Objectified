package com.cognizant.academy.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Module_Bo;
import com.cognizant.academy.Model.Objective;

public class ModuleServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
    public ModuleServlet() 
    {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("doGet");
		String act=request.getParameter("act");
		if(act!=null)
		{
			if(act.equals("getModules"))
			{
				getModuleList(request, response);
			}
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("DoPost");
		String act=request.getParameter("act");
		if(act!=null)
		{
			if(act.equals("modlist"))
			{
				getModuleList(request,response);
			}
			if(act.equals("addModule"))
			{
				addModule(request,response);
			}
			if(act.equals("objList"))
			{
				getObjectiveList(request,response);
			}
			if(act.equals("addObjective"))
			{
				addObjective(request,response);
			}
			if(act.equals("deleteObj"))
			{
				deleteObjective(request,response);
			}
		}
	}


	private void deleteObjective(HttpServletRequest request, HttpServletResponse response) 
	{
		//Method to delete selected objectives from a module
		 String[] names = request.getParameterValues("chk1");
		 Module_Bo bo=new Module_Bo(); 
		  for(String s:names)
		  {
			 boolean b=bo.removeObjective(s);
		  }
		  getModuleList(request, response);
		
	}


	private void addObjective(HttpServletRequest request, HttpServletResponse response) 
	{
		//Method to add objective to the selected Module
		HttpSession session=request.getSession();
		String Mod_name=(String) session.getAttribute("Mod");
		System.out.println(Mod_name);
		String Objective=request.getParameter("objective");
		Module_Bo bo=new Module_Bo(); 
		boolean result=bo.addObjective(Mod_name,Objective);
		getModuleList(request, response);
		
	}


	private void getObjectiveList(HttpServletRequest request, HttpServletResponse response) 
	{
		//Method to fetch list of objective for selected stack
		String stack=request.getParameter("stack_name");
		request.setAttribute("Stack_name",stack);
		Module_Bo modulebo=new Module_Bo();
	    List<String> olist=modulebo.fetchObjective_names(stack);
		request.setAttribute("ObjNames",olist);
		getModuleList(request, response);
		
	}


	private void addModule(HttpServletRequest request, HttpServletResponse response) 
	{
		//method to add the module to the selected course
		Module module=new Module();
        String name=request.getParameter("name");        
        module.setMod_name(name);
        Module_Bo modulebo=new Module_Bo();
        boolean result=modulebo.addModule(module);
        getModuleList(request,response);
		
	}


	private void getModuleList(HttpServletRequest request, HttpServletResponse response) //Sort of parent method since its called every time page is loaded
	{
		//Session to manage module page for each time a course request comes in
		HttpSession session=request.getSession();
		String course_id="101";
		if(course_id.equalsIgnoreCase((String)session.getAttribute("Mod_course")))
		{
		}
		else
		{
			session.removeAttribute("Mod");
		}
		session.setAttribute("Mod_course",course_id);
		
		//Fetching Module list for course_id
		 Module_Bo bo=new Module_Bo();        
	     List<String> mlist=bo.getModule_list(course_id);
	     request.setAttribute("ModList",mlist);
	     
	     
	     //fetching list of objectives for selected module to display on table
	     String Mod_name=request.getParameter("module");
	        if(Mod_name!=null)
	        {
	        session.setAttribute("Mod", Mod_name);
	        }
	        
	        if((String)session.getAttribute("Mod")==null)
	        {
	        request.setAttribute("Mod","Select Module");
	        }
	        else
	        {
	        	Mod_name=(String)session.getAttribute("Mod");
	        	request.setAttribute("Mod",Mod_name);
	        }
	        List<Objective> olist=bo.fetchobj(Mod_name);
	        request.setAttribute("Olist",olist);
	        
	        
	        //fetching List of stack for the dropdown
	        List<String> slist=bo.getStack_list();
	        String stack_name=request.getParameter("stack_name");
	        if(stack_name==null)
	        {
	        	request.setAttribute("stack_name","Select Stack");
	        }
	        else
	        {
	        	request.setAttribute("stack_name",stack_name);
	        }
	        request.setAttribute("StaList",slist);
	        
	        
	        //redirecting to modules.jsp page
	        RequestDispatcher dis=request.getRequestDispatcher("WEB-INF/View/Modules.jsp");
	        try 
	        {
				dis.forward(request, response);
			} 
	        catch (ServletException e) 
	        {
				
				e.printStackTrace();
			} 
	        catch (IOException e) 
	        {
				
				e.printStackTrace();
			}
		
	}

}
