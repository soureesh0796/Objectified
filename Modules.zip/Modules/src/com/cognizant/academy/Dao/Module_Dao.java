package com.cognizant.academy.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.academy.Model.Module;
import com.cognizant.academy.Model.Objective;
import com.cognizant.academy.utils.DbConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;


public class Module_Dao {
	
	
	public static List<String> getmodlist(String course_id) {
		Connection conn=null;
		PreparedStatement st = null;
		ResultSet rs = null;
		List<String> list=new ArrayList<String>();
		try 
		{
			conn=DbConnector.getConnection();
			st=conn.prepareStatement("select m.name from module m join course c on c.id=m.course_id where c.id=?");
			st.setString(1,course_id);
			rs=st.executeQuery();
			while(rs.next())
			{
				list.add(rs.getString(1));
			}
		} 
		catch (ClassNotFoundException e) 
		{
			
			e.printStackTrace();
		} catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		 finally
	        {
	              try
	              {
	                    conn.close();
	              }
	              catch(SQLException e)
	              {
	                    System.out.println(e.getMessage());
	              }
	        }
		return list;
		
	}

	
	
	public static boolean add(Module obj) 
	{
        boolean flag=false;
        Connection con=null;
        try
        {
              int module_id=generateModuleId();
              con=DbConnector.getConnection();
              PreparedStatement ps=con.prepareStatement("insert into module values(?,?,?)");
              ps.setInt(1, module_id);
              ps.setString(2,obj.getMod_name());
              ps.setInt(3,101);
              if(ps.executeUpdate()>0)
              {
                    flag=true;
              }
        }catch(SQLException e)
        {
              System.out.println(e.getMessage());
        }
        catch(ClassNotFoundException e)
        {
              System.out.println(e.getMessage());
        }
        finally
        {
              try
              {
                    con.close();
              }
              catch(SQLException e)
              {
                    System.out.println(e.getMessage());
              }
        }
        
        return flag;
  }

	
  private static int generateModuleId() 
  {
        Connection con=null;
        int count=0;
        int value=1000;
        int max=0;
        try{
        con = DbConnector.getConnection();
        PreparedStatement ps=con.prepareStatement("select count(id) from module");
        ResultSet rs=ps.executeQuery();
        if(rs.next()){
              count=rs.getInt(1);
        }
        if(count==0){
              value++;
        }
        else{
              PreparedStatement ps1=con.prepareStatement("select max(id) from module");
              ResultSet rs1=ps1.executeQuery();
              if(rs1.next()){
                    max=rs1.getInt(1);
              }
              value=max+1;
        }
        }
        catch(SQLException e)
        {
              System.out.println(e.getMessage());
        }
        catch(ClassNotFoundException e)
        {
              System.out.println(e.getMessage());
        }
        finally
        {
              try
              {
                    con.close();
              }
              catch(SQLException e)
              {
                    System.out.println(e.getMessage());
              }
        }
        return value;
        
  }

public static List<String> getStacklist() 
{
	Connection conn=null;
	PreparedStatement st = null;
	ResultSet rs = null;
	List<String> list=new ArrayList<String>();
	try 
	{
		conn=DbConnector.getConnection();
		st=conn.prepareStatement("select name from stack");
		rs=st.executeQuery();
		while(rs.next())
		{
			list.add(rs.getString(1));
		}
	} 
	catch (ClassNotFoundException e) 
	{
		
		e.printStackTrace();
	} 
	catch (SQLException e) 
	{
		
		e.printStackTrace();
	}
	 finally
     {
           try
           {
                 conn.close();
           }
           catch(SQLException e)
           {
                 System.out.println(e.getMessage());
           }
     }
	return list;
}



public static List<Objective> getObjectivelist(String name) 
{
	Connection conn=null;
	PreparedStatement st = null;
	ResultSet rs = null;
	List<Objective> list=new ArrayList<Objective>();
	try 
	{
		conn=DbConnector.getConnection();
		st=conn.prepareStatement("select s.name,o.name,o.duration from module m join objective o join stack s on o.module_id=m.id and o.stack_id=s.id where m.name=?");
		st.setString(1,name);
		rs=st.executeQuery();
		while(rs.next())
		{
			Objective o=new Objective();
			o.setStack_name(rs.getString(1));
			o.setObjective_name(rs.getString(2));
			o.setDuration(rs.getInt(3));
			list.add(o);
		}
	} 
	catch (ClassNotFoundException e) 
	{
		
		e.printStackTrace();
	} catch (SQLException e) 
	{
		
		e.printStackTrace();
	}
	 finally
     {
           try
           {
                 conn.close();
           }
           catch(SQLException e)
           {
                 System.out.println(e.getMessage());
           }
     }
	return list;
}



public static List<String> getObjectiveNames(String stack) 
{
	Connection conn=null;
	PreparedStatement st = null;
	ResultSet rs = null;
	List<String> list=new ArrayList<String>();
	try 
	{
	conn=DbConnector.getConnection();
	st=conn.prepareStatement("select o.name from objective o join stack s on o.stack_id=s.id where s.name=? and o.module_id is null");
	st.setString(1,stack);
	rs=st.executeQuery();
	while(rs.next())
	{	
		list.add(rs.getString(1));
	}
} 
catch (ClassNotFoundException e) 
{
	
	e.printStackTrace();
} catch (SQLException e) 
{
	
	e.printStackTrace();
}
	 finally
     {
           try
           {
                 conn.close();
           }
           catch(SQLException e)
           {
                 System.out.println(e.getMessage());
           }
     }
return list;
}



public static boolean addObjective(String Mod_name,String objective) 
{
	Connection conn=null;
	PreparedStatement st = null;
	ResultSet rs = null;
	boolean flag=false;
	try 
	{
		conn=DbConnector.getConnection();
		int mod_id=getModule_id(Mod_name);
		st=conn.prepareStatement("update objective set module_id=? where name=?");
		st.setInt(1,mod_id);
		st.setString(2,objective);
		int result=st.executeUpdate();
		if(result>0)
		{
			flag=true;
		}
	} 
	catch (ClassNotFoundException e) 
	{
		
		e.printStackTrace();
	} 
	catch (SQLException e) 
	{
		
		e.printStackTrace();
	}
	 finally
     {
           try
           {
                 conn.close();
           }
           catch(SQLException e)
           {
                 System.out.println(e.getMessage());
           }
     }
	return flag;
}



private static int getModule_id(String mod_name) 
{
	Connection conn=null;
	PreparedStatement st = null;
	ResultSet rs = null;
	int result=0;
	try 
	{
		conn=DbConnector.getConnection();
		st=conn.prepareStatement("select id from module where name=?");
		st.setString(1,mod_name);
		rs=st.executeQuery();
		if(rs.next())
		{
			result=rs.getInt(1);
		}
	} 
	catch (ClassNotFoundException e) 
	{
		
		e.printStackTrace();
	} 
	catch (SQLException e) 
	{
		
		e.printStackTrace();
	}
	 finally
     {
           try
           {
                 conn.close();
           }
           catch(SQLException e)
           {
                 System.out.println(e.getMessage());
           }
     }
	return result;
}



public static boolean removeObjective(String s) 
{
	Connection conn=null;
	PreparedStatement st = null;
	ResultSet rs = null;
	boolean flag=false;
	try 
	{
		conn=DbConnector.getConnection();
		st=conn.prepareStatement("update objective set module_id=null where name=?");
		st.setString(1,s);
		int result=st.executeUpdate();
		if(result>0)
		{
			flag=true;
		}
	} 
	catch (ClassNotFoundException e) 
	{
		
		e.printStackTrace();
	} 
	catch (SQLException e) 
	{
		
		e.printStackTrace();
	}
	 finally
     {
           try
           {
                 conn.close();
           }
           catch(SQLException e)
           {
                 System.out.println(e.getMessage());
           }
     }
	return flag;
}

		
}


