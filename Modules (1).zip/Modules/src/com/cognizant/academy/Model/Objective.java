package com.cognizant.academy.Model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity

@Table(name="objective")
public class Objective 
{
	private
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "stack_generatorss")
	@SequenceGenerator(name="stack_generatorss", sequenceName = "stack_seqqq" , initialValue = 1, allocationSize = 1)
	int id;
	String name;
	int duration;
	@OneToOne(cascade = CascadeType.ALL)
	Module module;
	@ManyToOne
    private Stack stack;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public Module getModule() {
		return module;
	}
	public void setModule(Module module) {
		this.module = module;
	}
	public Stack getStack() {
		return stack;
	}
	public void setStack(Stack stack) {
		this.stack = stack;
	}
	
}
